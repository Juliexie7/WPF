﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarDB
{
    static class Global
    {
        public static CarOwnerDbContext context = new CarOwnerDbContext();
    }
}
